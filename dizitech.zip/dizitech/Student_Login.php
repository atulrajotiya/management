<html>
<head>
<title>Student Login</title>
<link rel="stylesheet" href="css/bootstrap.css"  >
<link rel="stylesheet" href="css/bootstrap.min.css" >
</head>
<body>
<div class="container">
<div class="row">
<div class="col-md-6">
<form action="Student_Login_Process.php" method="post">
<label>Email ID</label>
<input type="email" class="form form-control" name="email" />
<label>Password</label>
<input type="password" class="form form-control" name="password" />
<input type="submit" name="submit"/>
</form>
</div>
</div>
</div>
</body>
</html>