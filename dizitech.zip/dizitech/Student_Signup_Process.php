<?php
include('include/config.php');
if(isset($_POST['submit']))
{
	try
	{
	if($_POST['pas1']==$_POST['pas2'])
		{
			$name=$_POST['name'];
			$mail=$_POST['email'];
			$pass1=$_POST['pas1'];
			$pass2= $_POST['pas2'];
			$roll=$_POST['roll'];
			$reg= $con->prepare("insert into student_register (name,email,password,rollno) VALUES (?,?,?,?)");
			$reg->bind_param("ssss",$name,$mail,$pass1,$roll);
			$reg->execute();
			$reg->close();
			echo "New records created successfully";
		}
		else
		{
			throw new Exception( "sorry no direct script allowed");
		}
	}

	catch(Exception $e)
	{
		echo "Error:".$e->getMessage();
	}
}
else
{
	throw new Exception( "sorry no direct script allowed");
}

?>