<!doctype>
<html>
<head>
  <title>Home Page</title>
  <?php
  
  require_once('facebook/autoload.php');?>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<style>
body{background-color: #337ab7;}
html, body, .container-table {
   height: 100%;

}
.container-table {
   display: table;
}

.vertical-center-row {
   display: table-cell;
   vertical-align: middle;
   font-size: 25px;
}
.vertical-center-row a{color:#fff;}
</style>
</head>
<body>
<?php
$fb = new Facebook\Facebook([
  'app_id' => '{1124740310936971}',
  'app_secret' => '{b85ea0eb76877aab899d3026eb576ad9}',
  'default_graph_version' => 'v2.5',
]);
?>
  <div class="container container-table">
      <div class="row vertical-center-row">
          <div class="text-center" style="color:rgb(255, 234, 71);border-bottom:1px solid rgb(255, 234, 71);margin-bottom:5px;">DIZITECH</div>
          <div class="text-center col-md-5 col-md-offset-3" >Login as <a href="Student_Login.php">Student</a> Or Login as <a href="login_faculty">Faculty</a> </div>
      </div>
  </div>
</body>
</html>
