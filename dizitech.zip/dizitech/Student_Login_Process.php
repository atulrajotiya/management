<?php

include('include/config.php');
if(isset($_POST['submit']))
{		
		$email=$_POST['email'];
		$pass=$_POST['password'];
		$sql=$con->prepare("select email,password from student_register where email=? and password=?");
		$sql->bind_param("ss",$email,$pass);
		$sql->execute();
		$result=$sql->get_result();
		$row=$result->fetch_array();
		if($pass==$row['password'] && $email==$row['email'])
		{
			echo "logged in";
		}
		else
		{
			echo "wrong credentials";
		}
		
		
		
		
}
else
{
	echo "No direct script please";
}
?>