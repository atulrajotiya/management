<?php

$con=mysqli_connect("localhost","root","","dizitech");
if(!$con)
{
	echo "oops something went wrong please try again later";
}