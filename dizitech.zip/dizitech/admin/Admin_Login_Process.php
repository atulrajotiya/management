<?php
include('../include/config.php');
session_start();
if(isset($_POST['submit']))
{
	$uname=$_POST['uname'];
	$pass=$_POST['password'];
	$sql=$con->prepare("select username,password from admin where username=? and password=?");
	$sql->bind_param("ss",$uname,$pass);
	$sql->execute();
	$result=$sql->get_result();
	$row=$result->fetch_assoc();
	
	if($uname==$row['username'] && $pass==$row['password'])
	{
		$_SESSION['admin']=$row['username'];
		header('location:Home.php');
	}
	else
	{
		echo "wrong credentials";
	}
}
else
{
	echo "no direct script please";
}
?>