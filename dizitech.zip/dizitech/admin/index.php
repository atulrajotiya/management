<html>
<head>
<title>Admin Login</title>
<link rel="stylesheet" href="../css/bootstrap.css"  >
<link rel="stylesheet" href="../css/bootstrap.min.css" >
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<form action="Admin_Login_Process.php" method="post">
				<label>Username</label>
				<input type="text" class="form form-control" name="uname" />
				<label>Password</label>
				<input type="password" class="form form-control" name="password" />
				<input type="submit" name="submit"/>
				</form>
			</div>
		</div>
	</div>
</body>
</html>