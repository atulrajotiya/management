<?php
session_start();
session_destroy();
unset($_SESSION['admin']);
echo "You Are Logged Out Succesfully";
?>