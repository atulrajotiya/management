<?php
session_start();
if(isset($_SESSION['admin']))
{
?>
<!DOCTYPE html>
<html>
<head>
<title>Student Login</title>
<link rel="stylesheet" href="../css/bootstrap.css"  >
<link rel="stylesheet" href="../css/bootstrap.min.css" >
</head>
<body>
<?php
include('navbar.php');
?>
</body>
</html>
<?php }
else
{
	echo "You Are Not Logged In";
}
?>