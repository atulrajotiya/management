<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form action="Student_Signup_Process.php" method="post">
<label>Name</label>
<input type="text" name="name" />
<label>Email</label>
<input type="text" name="email" />
<label>Password</label>
<input type="password" name="pas1" />
<label>Confirm Password</label>
<input type="password" name="pas2" />
<label>Roll No</label>
<input type="text" name="roll" />
<input type="submit" value="submit" name="submit">
</form>
</body>
</html>